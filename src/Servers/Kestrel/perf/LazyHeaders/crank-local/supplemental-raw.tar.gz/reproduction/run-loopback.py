import argparse
import datetime
import hashlib
import json
import pathlib
import subprocess
import time
import urllib.error
import urllib.request


def read_json(url):
    with urllib.request.urlopen(url, timeout=5) as response:
        return json.load(response)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


parser = argparse.ArgumentParser()
parser.add_argument("--controller", type=pathlib.Path, required=True)
parser.add_argument("--repo", type=pathlib.Path, required=True)
parser.add_argument("--head", type=pathlib.Path, required=True)
parser.add_argument("--base", type=pathlib.Path, required=True)
parser.add_argument("--runtime", type=pathlib.Path, required=True)
parser.add_argument("--output", type=pathlib.Path, required=True)
parser.add_argument("--repetitions", type=int, default=5)
parser.add_argument("--warmup", type=int, default=15)
parser.add_argument("--duration", type=int, default=30)
parser.add_argument("--case", action="append", dest="cases")
parser.add_argument("--resume", action="store_true")
parser.add_argument("--record-errors", action="store_true")
args = parser.parse_args()
args.output.mkdir(parents=True, exist_ok=args.resume)
assert args.repetitions > 0 and args.warmup > 0 and args.duration > 0
config = args.repo / "src/Servers/Kestrel/perf/lazy-headers.crank.yml"
profile = args.repo / "src/Servers/Kestrel/perf/LazyHeaders/loopback-poc.yml"
core = "Microsoft.AspNetCore.Server.Kestrel.Core.dll"
hashes = {"base": digest(args.base / core), "head": digest(args.head / core)}
cases = args.cases or ["ignore:stable", "ignore:changing", "read:stable", "read:changing"]
plan = []
variants = ["base", "off", "on"]
for repetition in range(args.repetitions):
    order = variants[repetition % 3:] + variants[:repetition % 3]
    for case in cases[::1 if repetition % 2 == 0 else -1]:
        access, mode = case.split(":")
        assert access in {"ignore", "read", "enumerate"}
        assert mode in {"stable", "changing", "duplicate"}
        for variant in order:
            plan.append(dict(repetition=repetition + 1, access=access, mode=mode, variant=variant))
if args.resume:
    assert json.loads((args.output / "plan.json").read_text()) == plan
else:
    write_json(args.output / "plan.json", plan)
    write_json(args.output / "inputs.json", {
    "startedUtc": now(), "headPayload": str(args.head), "basePayload": str(args.base),
    "coreSha256": hashes, "controllerSha256": digest(args.controller),
    "configSha256": digest(config), "profileSha256": digest(profile),
    "warmupSeconds": args.warmup, "measurementSeconds": args.duration,
    "sharedLoopback": True, "serverRuntimeRoot": str(args.runtime),
    })
agent = "http://127.0.0.1:15010"
assert read_json(agent + "/jobs") == [], "Agent already has jobs"
for index, run in enumerate(plan):
    name = f"{index + 1:03d}-{run['variant']}-{run['access']}-{run['mode']}"
    folder = args.output / name
    if folder.exists():
        result_path = folder / "result.json"
        if result_path.exists():
            previous = json.loads(result_path.read_text())
            metrics = previous["jobResults"]["jobs"]["load"]["results"]
            assert previous["returnCode"] == 0
            assert metrics["http/requests"] > 0 and metrics["http/rps/mean"] > 0
            if not args.record_errors:
                assert metrics["http/requests/badresponses"] == 0 and metrics["http/requests/errors"] == 0
            assert (folder / "loaded-identity.json").exists()
            continue
        interrupted = args.output / "interrupted"
        interrupted.mkdir(exist_ok=True)
        folder.rename(interrupted / (name + "-" + str(time.time_ns())))
    folder.mkdir()
    payload = args.base if run["variant"] == "base" else args.head
    command = [
        "dotnet", str(args.controller), "--config", str(config), "--config", str(profile),
        "--scenario", "lazy-headers", "--profile", "loopback-poc",
        "--application.source.localFolder", str(payload),
        "--load.source.localFolder", "/tmp/lhp-7a143fff/wrk-wrapper",
        "--load.source.project", "",
        "--load.project", "",
        "--variable", f"pocDotnetRoot={args.runtime}",
        "--variable", "wrkWrapperPublish=/tmp/lhp-7a143fff/wrk-wrapper",
        "--variable", f"access={run['access']}",
        "--variable", f"lazy={'true' if run['variant'] == 'on' else 'false'}",
        "--variable", f"headerMode={run['mode']}",
        "--variable", "headerScript=https://raw.githubusercontent.com/dotnet/aspnetcore/1abb44340f48a2bba2ded49cb883aa172deeb27e/src/Servers/Kestrel/perf/lazy-headers.wrk.lua",
        "--load.variables.warmup", str(args.warmup),
        "--load.variables.duration", str(args.duration),
        "--load.variables.connections", "16",
        "--load.variables.threads", "2",
        "--load.variables.timeout", "10",
    ]
    with (folder / "render.log").open("w") as log:
        subprocess.run(command + ["--debug", str(folder / "resolved.json")], stdout=log, stderr=subprocess.STDOUT, check=True)
    resolved = json.loads((folder / "resolved.json").read_text())
    assert resolved["Jobs"]["application"]["Sources"]["default"]["LocalFolder"] == str(payload)
    assert resolved["Jobs"]["application"]["EnvironmentVariables"]["DOTNET_ROOT"] == str(args.runtime)
    assert f"-d {args.duration}s" in resolved["Jobs"]["load"]["Arguments"]
    record = {**run, "startedUtc": now(), "command": command}
    write_json(folder / "execution.json", record)
    identity = None
    deadline = time.monotonic() + 600
    with (folder / "controller.log").open("w") as log:
        process = subprocess.Popen(command + ["--json", str(folder / "result.json")], stdout=log, stderr=subprocess.STDOUT)
        try:
            while process.poll() is None:
                if time.monotonic() > deadline:
                    raise TimeoutError(f"Crank run exceeded 600 seconds: {name}")
                if identity is None:
                    for queued in read_json(agent + "/jobs"):
                        try:
                            job = read_json(agent + f"/jobs/{queued['id']}")
                        except urllib.error.HTTPError as error:
                            if error.code != 404:
                                raise
                            continue
                        if job.get("executable") != "LazyHeadersApp" or not job.get("processId"):
                            continue
                        pid = job.get("activeProcessId") or job["processId"]
                        maps = pathlib.Path(f"/proc/{pid}/maps").read_text()
                        paths = {line.split(maxsplit=5)[-1] for line in maps.splitlines() if "/" in line}
                        loaded_core = next((pathlib.Path(p) for p in paths if p.endswith("/" + core)), None)
                        if loaded_core is not None:
                            runtime = next(p for p in paths if p.endswith("/libcoreclr.so"))
                            assert str(args.runtime) in runtime, runtime
                            assert digest(loaded_core) == hashes["base" if run["variant"] == "base" else "head"]
                            identity = {"timestampUtc": now(), "pid": pid, "corePath": str(loaded_core),
                                        "coreSha256": digest(loaded_core), "runtimePath": runtime,
                                        "runtimeSha256": digest(pathlib.Path(runtime))}
                            write_json(folder / "loaded-identity.json", identity)
                time.sleep(1)
        finally:
            if process.poll() is None:
                process.terminate()
                process.wait(timeout=20)
    record.update(endedUtc=now(), exitCode=process.returncode)
    write_json(folder / "execution.json", record)
    assert process.returncode == 0, f"Crank failed: {name}, see controller.log"
    assert identity is not None, f"No loaded server identity captured: {name}"
    document = json.loads((folder / "result.json").read_text())
    assert document["returnCode"] == 0
    result = document["jobResults"]["jobs"]
    assert result["application"]["measurements"], f"No application measurements: {name}"
    metrics = result["load"]["results"]
    assert metrics["http/requests"] > 0 and metrics["http/rps/mean"] > 0
    if not args.record_errors:
        assert metrics["http/requests/badresponses"] == 0
        assert metrics["http/requests/errors"] == 0
    for percentile in ["50", "75", "90", "99"]:
        assert metrics[f"http/latency/{percentile}"] > 0
    assert result["load"]["measurements"], f"No load measurements: {name}"
    assert read_json(agent + "/jobs") == [], f"Agent jobs remain after cleanup: {name}"
    print(f"{name}: {metrics['http/rps/mean']} RPS; bad={metrics['http/requests/badresponses']}, socket-errors={metrics['http/requests/errors']}", flush=True)
write_json(args.output / "completed.json", {"endedUtc": now(), "runs": len(plan)})
