import csv
import datetime
import json
import pathlib
import statistics
import sys

root = pathlib.Path(sys.argv[1])
rows = []


def stamp(value):
    return datetime.datetime.fromisoformat(value.replace("Z", "+00:00"))


for folder in sorted(root.glob("[0-9]*")):
    result = json.loads((folder / "result.json").read_text())
    assert result["returnCode"] == 0
    jobs = result["jobResults"]["jobs"]
    load = jobs["load"]["results"]
    execution = json.loads((folder / "execution.json").read_text())
    samples = [sample for group in jobs["load"]["measurements"] for sample in group]
    end = min(stamp(s["timestamp"]) for s in samples if s["name"] == "http/rps/mean")
    # Wrapper emits result metrics after wrk exits. Trim both ends to avoid
    # startup/warmup and completion samples; do not claim request normalization.
    start = end - datetime.timedelta(seconds=27)
    stop = end - datetime.timedelta(seconds=3)
    row = {key: execution[key] for key in ["repetition", "access", "mode", "variant"]}
    row.update(run=folder.name, rps=load["http/rps/mean"], requests=load["http/requests"],
               bad_responses=load["http/requests/badresponses"],
               socket_errors=load["http/requests/errors"])
    for percentile in ["50", "75", "90", "99"]:
        row[f"latency_p{percentile}_ms"] = load[f"http/latency/{percentile}"]
    for job, prefix in [("application", "server"), ("load", "client")]:
        values = [s for group in jobs[job]["measurements"] for s in group
                  if start <= stamp(s["timestamp"]) <= stop]
        for metric, label in [
            ("runtime-counter/alloc-rate", "allocation_bytes_per_second"),
            ("runtime-counter/time-in-gc", "time_in_gc_percent"),
            ("runtime-counter/gen-0-gc-count", "gen0_per_second"),
            ("runtime-counter/gen-1-gc-count", "gen1_per_second"),
            ("runtime-counter/gen-2-gc-count", "gen2_per_second"),
            ("benchmarks/cpu/raw", "cpu_core_percent"),
            ("benchmarks/cpu/global", "global_cpu_percent"),
            ("benchmarks/working-set", "working_set_mb"),
        ]:
            selected = [float(s["value"]) for s in values if s["name"] == metric]
            row[f"{prefix}_{label}_sample_count"] = len(selected)
            row[f"{prefix}_{label}_mean"] = statistics.mean(selected) if selected else None
    row.update(trimmed_window_start=start.isoformat(), trimmed_window_end=stop.isoformat())
    assert row["server_allocation_bytes_per_second_sample_count"] >= 15
    assert row["bad_responses"] == 0 and row["socket_errors"] == 0
    rows.append(row)
with (root / "derived-runs.csv").open("w", newline="") as file:
    writer = csv.DictWriter(file, fieldnames=rows[0].keys(), lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
summary = []
for access in sorted({r["access"] for r in rows}):
    for mode in sorted({r["mode"] for r in rows}):
        for variant in ["base", "off", "on"]:
            group = [r for r in rows if (r["access"], r["mode"], r["variant"]) == (access, mode, variant)]
            assert len(group) >= 5
            item = dict(access=access, mode=mode, variant=variant, repetitions=len(group))
            for key in ["rps", "latency_p99_ms", "server_allocation_bytes_per_second_mean",
                        "server_cpu_core_percent_mean", "client_cpu_core_percent_mean",
                        "server_time_in_gc_percent_mean", "server_working_set_mb_mean"]:
                values = [r[key] for r in group if r[key] is not None]
                item[key] = dict(median=statistics.median(values), minimum=min(values),
                                 maximum=max(values), mean=statistics.mean(values),
                                 standard_deviation=statistics.stdev(values)) if values else None
            summary.append(item)
(root / "derived-summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
