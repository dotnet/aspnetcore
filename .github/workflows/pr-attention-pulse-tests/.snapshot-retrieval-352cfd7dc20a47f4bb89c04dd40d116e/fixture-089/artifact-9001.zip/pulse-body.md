# Local Pulse retrieval fixture

<details>
<summary>Blazor</summary>

Captured area A.

</details>

<details>
<summary>Repository-wide</summary>

Captured area B.

</details>

## Snapshot

Snapshot generated: `2026-09-23T19:30:00.0000000Z`. [Producing workflow run](https://github.com/dotnet/aspnetcore/actions/runs/34643961191/attempts/1).
Artifact: `pulse-publication-evidence`; files: `pulse-input.json`, `pulse-body.md`.
Capped report results, not the full queue. Authenticated ZIP artifact retained for seven days as secondary audit evidence.

<details>
<summary>Snapshot identity</summary>

Repository: `dotnet/aspnetcore`; run ID: `34643961191`; attempt: `1`.
JSON SHA-256: `bb8892eccfa9590dbfb0f6367059fdf808de62a1b47e5a8068ded2f103002efe`.

</details>

<details>
<summary>Snapshot JSON</summary>

The exact JSON does not fit within the issue body size limit for this snapshot and is not embedded here.
Retrieve the identical bytes from the `pulse-publication-evidence` artifact and verify them against the checksum above.

</details>
